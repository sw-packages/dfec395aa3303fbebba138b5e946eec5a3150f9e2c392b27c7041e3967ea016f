#ifndef _RE2C_MSG_VER_
#define _RE2C_MSG_VER_

#include <string>

namespace re2c {

std::string ver_to_vernum(const char* ver);

} // namespace re2c

#endif // _RE2C_MSG_VER_
